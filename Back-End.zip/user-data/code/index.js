const express = require("express");
const morgan = require("morgan");
const bodyParser = require("body-parser");
const mysql = require("mysql");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "nodemysql",
}); //details of the xampp server

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log("MySql connected");
});

const app = express();
const port = process.env.PORT || 8080; //determines port

app //below listed all methods the express api can do
  .use(morgan("dev"))
  .use(express.static("public")) //serves this js file into the files in public folder(where) HTML is you can't insert node files in script tag
  .use(bodyParser.urlencoded({ extended: false }))
  .use(bodyParser.json())

  .post("/api/admin", (req, res) => {
    let phno = req.body.phno;
    let cc = req.body.cc;
    let dob = req.body.age;
    let fname = req.body.fname;
    let lname = req.body.lname;
    let pass = req.body.pass;
    let email = req.body.email;
    //req-recieves from html in public folder
    //.body-body parser module parses info from the body
    //.phno,.cc  are names given to the input

    let adduser =
      "INSERT INTO `admin` (`FirstName`,`LastName`,`Email`,`DoB`,`Password`,`CountryCode`,`PhoneNumber`) VALUES (?,?,?,?,?,?,?)";

    try {
      db.query(adduser, [fname, lname, email, dob, pass, cc, phno], (err) => {
        //exedutes query
        if (err) {
          res.send(err.message);
        }
        res.send("Done inserting");
      });
    } catch (error) {
      res.json(res.send(error.message));
    }
  })

  .post("/api/user", (req, res) => {
    //  /api/user acton of the from to be executed
    let phno = req.body.phno;
    let cc = req.body.cc;
    let dob = req.body.age;
    let fname = req.body.fname;
    let lname = req.body.lname;
    let pass = req.body.pass;
    let email = req.body.email;

    let adduser =
      "INSERT INTO `user` (`FirstName`,`LastName`,`Email`,`DoB`,`Password`,`CountryCode`,`PhoneNumber`) VALUES (?,?,?,?,?,?,?)";

    console.log("country code " + cc);

    try {
      db.query(adduser, [fname, lname, email, dob, pass, cc, phno], (err) => {
        if (err) {
          res.send(err.message);
        }
        res.send("Done inserting");
      });
    } catch (error) {
      res.json(res.send(error.message));
    }
  })

  .post("/api/exam", (req, res) => {
    //doesn't work yet
    let sql = "CREATE DATABASE nodemysql";
    db.query(sql, (err) => {
      //query executed  here
      if (err) {
        throw err;
      }

      res.send("Database Created");
    });
  })

  .post("/get/exam", (req, res) => {
    const { table } = req.body;
    let getexam = `SELECT * FROM ${table} `;

    const users = db.query(getexam, [table], function (err, result, fields) {
      if (err) throw err;
      res.send(result);
    });
  })

  .get("/data", (req, res) => {
    //  /data like action but found in the div property data-url
    let getexam = `SELECT * FROM user `;

    db.query(getexam, function (err, result, fields) {
      if (err) throw err;
      console.log(result);
      res.send(result);
      console.log("reponse sent");
    });
  })

  .listen(port, () => console.log(`Server running on port ${port}`));
